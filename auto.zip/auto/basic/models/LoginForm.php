<?php

namespace app\models;

use Yii;
use mdm\admin\models\form\Login as LoginModel;

class LoginForm extends LoginModel
{

}
