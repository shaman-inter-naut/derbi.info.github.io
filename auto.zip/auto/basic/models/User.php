<?php

namespace app\models;

use mdm\admin\models\User as UserModel;

class User extends UserModel
{

}
