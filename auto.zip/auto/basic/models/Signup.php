<?php

namespace app\models;

use mdm\admin\models\form\SignUp as SignupModel;

class Signup extends SignupModel
{

}