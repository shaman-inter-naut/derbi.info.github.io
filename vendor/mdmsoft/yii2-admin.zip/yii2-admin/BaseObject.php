<?php

namespace mdm\admin;

if(!class_exists('yii\base\BaseObject')){
    class_alias('yii\base\Object', 'yii\base\BaseObject');
}

/**
 * Description of BaseObject
 *
 * @author Misbahul D Munir <misbahuldmunir@gmail.com>
 * @since 2.9
 */
class BaseObject extends \yii\base\BaseObject
{
    //put your code here
}
